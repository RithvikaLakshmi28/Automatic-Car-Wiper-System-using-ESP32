/*
  Automatic Car Wiper System using ESP32
  Educational prototype.
*/

const int RAIN_PIN = 34;
const int MOTOR_PWM = 25;
const int MOTOR_DIR = 26;
const int STATUS_LED = 2;

const int DRY_THRESHOLD = 3000;
const int LIGHT_RAIN = 2200;
const int HEAVY_RAIN = 1200;

const int PWM_CHANNEL = 0;
const int PWM_FREQ = 1000;
const int PWM_RESOLUTION = 8;

void setWiperSpeed(int speed)
{
  speed = constrain(speed, 0, 255);
  digitalWrite(MOTOR_DIR, HIGH);
  ledcWrite(PWM_CHANNEL, speed);
}

void setup()
{
  Serial.begin(115200);
  pinMode(MOTOR_DIR, OUTPUT);
  pinMode(STATUS_LED, OUTPUT);

  ledcSetup(PWM_CHANNEL, PWM_FREQ, PWM_RESOLUTION);
  ledcAttachPin(MOTOR_PWM, PWM_CHANNEL);
  setWiperSpeed(0);
}

void loop()
{
  int rainValue = analogRead(RAIN_PIN);

  Serial.print("Rain ADC: ");
  Serial.println(rainValue);

  if (rainValue > DRY_THRESHOLD)
  {
    setWiperSpeed(0);
    digitalWrite(STATUS_LED, LOW);
  }
  else if (rainValue > LIGHT_RAIN)
  {
    setWiperSpeed(100);
    digitalWrite(STATUS_LED, HIGH);
  }
  else if (rainValue > HEAVY_RAIN)
  {
    setWiperSpeed(180);
    digitalWrite(STATUS_LED, HIGH);
  }
  else
  {
    setWiperSpeed(255);
    digitalWrite(STATUS_LED, HIGH);
  }

  delay(100);
}
