# Suggested Pinout

| Function | ESP32 pin | Notes |
|---|---:|---|
| Rain sensor analog | GPIO34 | ADC |
| Motor PWM | GPIO25 | Driver input |
| Motor direction | GPIO26 | Driver input |
| Status LED | GPIO2 | Optional |
| Ground | GND | Common logic ground |
