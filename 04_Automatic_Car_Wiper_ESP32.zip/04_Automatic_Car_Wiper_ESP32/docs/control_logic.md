# Control Logic

| Rain ADC | Prototype action |
|---|---|
| > 3000 | Wiper OFF |
| 2200–3000 | Low speed |
| 1200–2200 | Medium speed |
| < 1200 | High speed |

Thresholds are starting values and should be calibrated for the actual rain sensor and installation.
