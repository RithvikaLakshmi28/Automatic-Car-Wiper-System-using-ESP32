# Automatic Car Wiper System using ESP32

An embedded automotive prototype that detects rainfall and controls a wiper motor with multiple speed levels.

## Hardware
- ESP32
- Rain sensor
- DC geared wiper motor
- High-current motor driver / MOSFET stage
- 12 V supply with appropriate protection
- Optional washer pump and display

## Files
- `src/automatic_wiper_esp32.ino`
- `docs/pinout.md`
- `docs/control_logic.md`
- `block_diagram.png`

> Never connect a wiper motor directly to an ESP32 GPIO. Use a suitable high-current driver, fuse, flyback/protection circuitry, and automotive-rated power stage.
